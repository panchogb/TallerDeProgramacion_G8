package Modelo;

public class Internet100 extends Contratacion {
  /**
         *    El constructor asigna los valores a las variables previstas en
         * la clase Contratación (factura= 'Internet 100' y costo = 850.
        */
	public Internet100() {
		this.factura = "Internet 100";
		this.costo = 850;
	}

}
