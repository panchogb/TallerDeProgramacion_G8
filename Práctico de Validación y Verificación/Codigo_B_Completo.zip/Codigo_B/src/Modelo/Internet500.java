package Modelo;

public class Internet500 extends Contratacion {
    
        /**
         *  El constructor asigna los valores a las variables previstas en
         * la clase Contratación (factura= 'Internet 500' y costo = 1000.
        */
	public Internet500() {
		this.factura = "Internet 500";
		this.costo = 1000;
	}

}
