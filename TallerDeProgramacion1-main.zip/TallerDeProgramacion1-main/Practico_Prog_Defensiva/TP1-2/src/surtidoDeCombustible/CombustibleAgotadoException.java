package surtidoDeCombustible;

public class CombustibleAgotadoException extends Exception {

}
