package surtidoDeCombustible;

public class DemasiadoCombustibleException extends Exception {

}
