package surtidoDeCombustible;

public class ImposibleActivarException extends Exception {

}
