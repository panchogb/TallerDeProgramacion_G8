package surtidoDeCombustible;

public class Manguera {
    private int numero;
    private boolean estado;
}