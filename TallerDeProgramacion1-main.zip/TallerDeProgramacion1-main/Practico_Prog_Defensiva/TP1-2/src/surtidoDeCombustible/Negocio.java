package surtidoDeCombustible;

public class Negocio {

}
