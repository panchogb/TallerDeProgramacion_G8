package surtidoDeCombustible;

public class SurtidorVacioException extends Exception {

}
