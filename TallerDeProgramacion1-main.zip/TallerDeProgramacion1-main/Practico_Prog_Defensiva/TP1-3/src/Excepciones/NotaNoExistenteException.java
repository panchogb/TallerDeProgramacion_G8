package Excepciones;

public class NotaNoExistenteException extends Exception {

	public NotaNoExistenteException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
