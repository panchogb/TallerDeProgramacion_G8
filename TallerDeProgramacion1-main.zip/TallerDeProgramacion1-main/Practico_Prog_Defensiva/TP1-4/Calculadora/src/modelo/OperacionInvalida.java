package modelo;

public class OperacionInvalida extends Exception {

}
