package modelo;

public class ResultadoInvalido extends Exception {

}
