package vista;

import controlador.Monitor;

public interface IVentana {
	public void arranca();
	
	public void setControlador(Monitor m);
	
}
