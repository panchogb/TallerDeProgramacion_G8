package modelo;

public class NumeroNoValidoException extends Exception {

}
