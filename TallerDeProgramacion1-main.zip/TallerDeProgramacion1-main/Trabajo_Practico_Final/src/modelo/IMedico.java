package modelo;

public interface IMedico {
	
	double getHonorario();
	
	String getMatricula();
	
	String getEspecialidad();
	
	String getNombre();

}
