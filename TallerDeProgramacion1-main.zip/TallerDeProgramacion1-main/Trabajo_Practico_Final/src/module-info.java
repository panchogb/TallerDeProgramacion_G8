module tpg {
	requires java.desktop;
}